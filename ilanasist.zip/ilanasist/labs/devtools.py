"""Capstone C — Incident triage için sahte gözlemlenebilirlik araçları.

Tüm veri sentetiktir; hiçbir gerçek sisteme bağlanmaz. Aynı seed ile
her çalıştırmada aynı olayları üretir, böylece eval tekrarlanabilir olur.
"""
import json
import random
from datetime import datetime, timedelta
from functools import cache
from pathlib import Path

from langchain_core.tools import tool

DATA = Path(__file__).resolve().parent.parent / "data" / "incidents.json"
SERVICES = ["ilan-api", "arama-servisi", "odeme-servisi", "bildirim-worker", "resim-isleyici"]
T0 = datetime(2026, 3, 14, 9, 0)


def _gen() -> dict:
    rnd = random.Random(20260314)
    deploys, logs, metrics, alerts = [], [], [], []

    # --- deploy geçmişi
    for i in range(12):
        svc = rnd.choice(SERVICES)
        deploys.append({
            "id": f"D-{2000 + i}",
            "service": svc,
            "at": (T0 - timedelta(minutes=rnd.randint(5, 900))).isoformat(timespec="minutes"),
            "version": f"v{rnd.randint(1, 9)}.{rnd.randint(0, 20)}.{rnd.randint(0, 9)}",
            "author": f"dev-{rnd.randint(1, 8)}",
            "summary": rnd.choice([
                "bağlantı havuzu ayarı güncellendi", "yeni önbellek katmanı",
                "bağımlılık yükseltmesi", "sorgu optimizasyonu",
                "özellik bayrağı açıldı", "log seviyesi düşürüldü",
            ]),
        })
    # kök neden: olaydan 18 dk önce ilan-api'ye yapılan deploy
    deploys.append({
        "id": "D-2099", "service": "ilan-api",
        "at": (T0 - timedelta(minutes=18)).isoformat(timespec="minutes"),
        "version": "v4.12.0", "author": "dev-3",
        "summary": "veritabanı bağlantı havuzu 50'den 5'e düşürüldü (yanlışlıkla)",
    })

    # --- metrikler: 60 dakikalık pencere, olay T0-15'te başlıyor
    for svc in SERVICES:
        for m in range(60):
            ts = (T0 - timedelta(minutes=59 - m)).isoformat(timespec="minutes")
            broken = svc == "ilan-api" and m >= 44
            downstream = svc == "arama-servisi" and m >= 47
            metrics.append({
                "service": svc, "at": ts,
                "p95_ms": round(rnd.uniform(120, 260) * (7.5 if broken else 2.2 if downstream else 1), 1),
                "error_rate": round(rnd.uniform(0.001, 0.01) + (0.28 if broken else 0.06 if downstream else 0), 4),
                "rps": round(rnd.uniform(400, 700), 1),
            })

    # --- loglar
    for m in range(44, 60):
        ts = (T0 - timedelta(minutes=59 - m)).isoformat(timespec="minutes")
        logs.append({"service": "ilan-api", "at": ts, "level": "ERROR",
                     "message": "TimeoutError: connection pool exhausted (size=5, waiting=63)"})
        if m % 3 == 0:
            logs.append({"service": "arama-servisi", "at": ts, "level": "WARN",
                         "message": "upstream ilan-api yanıt vermedi, devre kesici açıldı"})
    for m in range(0, 44, 6):
        ts = (T0 - timedelta(minutes=59 - m)).isoformat(timespec="minutes")
        logs.append({"service": rnd.choice(SERVICES), "at": ts, "level": "INFO",
                     "message": rnd.choice(["istek tamamlandı", "önbellek yenilendi", "sağlık kontrolü ok"])})

    alerts.append({
        "id": "A-5001", "service": "ilan-api", "severity": "critical",
        "at": (T0 - timedelta(minutes=12)).isoformat(timespec="minutes"),
        "title": "ilan-api p95 gecikme eşiği aşıldı",
        "detail": "p95 > 1500ms, 5 dakikadır sürüyor. Hata oranı %28.",
    })
    return {"deploys": deploys, "logs": logs, "metrics": metrics, "alerts": alerts}


@cache
def _data() -> dict:
    if not DATA.exists():
        DATA.parent.mkdir(parents=True, exist_ok=True)
        DATA.write_text(json.dumps(_gen(), ensure_ascii=False, indent=1), encoding="utf-8")
    return json.loads(DATA.read_text(encoding="utf-8"))


@tool
def get_alert(alert_id: str) -> dict:
    """Bir alarmın detayını döndürür: servis, önem derecesi, zaman ve açıklama.

    Triyaja her zaman buradan başla. Alarm kimliği A-5001 biçimindedir.
    """
    for a in _data()["alerts"]:
        if a["id"] == alert_id:
            return a
    return {"error": f"{alert_id} bulunamadı. Mevcut alarmlar: "
                     f"{[a['id'] for a in _data()['alerts']]}"}


@tool
def search_logs(service: str, level: str | None = None, limit: int = 20) -> dict:
    """Bir servisin loglarını döndürür (en yeni önce).

    level: ERROR, WARN veya INFO. Hata ayıklarken önce ERROR ile bak.
    Servis adları: ilan-api, arama-servisi, odeme-servisi, bildirim-worker, resim-isleyici.
    """
    rows = [x for x in _data()["logs"] if x["service"] == service
            and (level is None or x["level"] == level)]
    rows.sort(key=lambda x: x["at"], reverse=True)
    return {"total": len(rows), "items": rows[:min(limit, 50)]}


@tool
def get_metrics(service: str, minutes: int = 60) -> dict:
    """Bir servisin son N dakikalık p95 gecikme, hata oranı ve istek hızı serisini döndürür.

    Ayrıca pencerenin ilk ve son üçte birini karşılaştıran bir özet verir;
    bozulmanın ne zaman başladığını bulmak için bunu kullan.
    """
    rows = [x for x in _data()["metrics"] if x["service"] == service][-min(minutes, 60):]
    if not rows:
        return {"error": f"{service} için metrik yok. Servisler: {SERVICES}"}
    third = max(len(rows) // 3, 1)
    head, tail = rows[:third], rows[-third:]
    avg = lambda xs, k: round(sum(x[k] for x in xs) / len(xs), 4)
    return {
        "service": service, "points": len(rows),
        "baseline": {"p95_ms": avg(head, "p95_ms"), "error_rate": avg(head, "error_rate")},
        "current": {"p95_ms": avg(tail, "p95_ms"), "error_rate": avg(tail, "error_rate")},
        "series": rows[::5],
    }


@tool
def list_deploys(service: str | None = None, limit: int = 10) -> dict:
    """Son deploy'ları döndürür (en yeni önce). service verilirse o servise filtreler.

    Bir olayın kök nedenini ararken olaydan hemen önceki deploy'lara bak.
    """
    rows = [x for x in _data()["deploys"] if service is None or x["service"] == service]
    rows.sort(key=lambda x: x["at"], reverse=True)
    return {"total": len(rows), "items": rows[:min(limit, 20)]}


# ---------------------------------------------------------------- yazma aracı
TICKETS: list[dict] = []


@tool
def create_ticket(title: str, service: str, severity: str, summary: str,
                  idempotency_key: str | None = None) -> dict:
    """Olay kaydı (ticket) oluşturur. YAZMA ARACI — insan onayı olmadan çağrılmamalıdır.

    severity: low, medium, high, critical.
    summary: ne oldu, ne zaman başladı, olası kök neden, önerilen ilk adım.
    Aynı idempotency_key ile tekrar çağrılırsa yeni kayıt açmaz.
    """
    if severity not in {"low", "medium", "high", "critical"}:
        return {"error": "severity low, medium, high veya critical olmalı"}
    if idempotency_key:
        for t in TICKETS:
            if t.get("idempotency_key") == idempotency_key:
                return {"ok": True, "duplicate": True, "ticket": t}
    ticket = {"id": f"INC-{7000 + len(TICKETS)}", "title": title, "service": service,
              "severity": severity, "summary": summary, "idempotency_key": idempotency_key}
    TICKETS.append(ticket)
    return {"ok": True, "duplicate": False, "ticket": ticket}


READ_TOOLS = [get_alert, search_logs, get_metrics, list_deploys]
ALL_TOOLS = [*READ_TOOLS, create_ticket]


if __name__ == "__main__":
    print("alarm:", get_alert.invoke({"alert_id": "A-5001"}))
    print("\nmetrik:", get_metrics.invoke({"service": "ilan-api"})["baseline"],
          "→", get_metrics.invoke({"service": "ilan-api"})["current"])
    print("\nlog:", search_logs.invoke({"service": "ilan-api", "level": "ERROR", "limit": 2}))
    print("\ndeploy:", list_deploys.invoke({"service": "ilan-api", "limit": 2}))
