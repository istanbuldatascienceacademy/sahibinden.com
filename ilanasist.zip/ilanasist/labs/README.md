# Lab çözümleri

Her lab'ın çözümünü bu klasöre yazın: `lab1_react.py`, `lab2_graph.py`, ...
Çalıştırma: `uv run python -m labs.lab1_react`
Adım adım talimatlar: `../LAB_GUIDE.md`
