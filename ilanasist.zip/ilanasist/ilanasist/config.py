"""Model yapılandırması. Tüm lab'lar LLM'i buradan alır."""
import os

from dotenv import load_dotenv
from langchain.chat_models import init_chat_model

load_dotenv()

_ROLES = {
    "default": "MODEL",      # ana muhakeme modeli
    "planner": "MODEL",      # plan üretimi
    "fast": "FAST_MODEL",    # ucuz/hızlı adımlar (router, executor, judge)
}


def get_llm(role: str = "default", **kwargs):
    """Rolüne göre sohbet modelini döndürür (ör. get_llm("fast"))."""
    env_key = _ROLES.get(role, "MODEL")
    model = os.getenv(env_key) or os.getenv("MODEL")
    if not model:
        raise RuntimeError("MODEL tanımlı değil. .env.example dosyasını .env olarak kopyalayın.")
    return init_chat_model(model, temperature=kwargs.pop("temperature", 0), **kwargs)


if __name__ == "__main__":
    llm = get_llm()
    ai = llm.invoke("Tek cümleyle: agentic AI nedir?")
    print(f"[{os.getenv('MODEL')}] {ai.text}")
    print("Token kullanımı:", ai.usage_metadata)
