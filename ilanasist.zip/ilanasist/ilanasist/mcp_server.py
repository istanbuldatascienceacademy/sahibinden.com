"""İlanAsist araçlarını MCP sunucusu olarak yayınlar (Lab 0 bonus / Modül 2).

Cursor: .cursor/mcp.json bu sunucuyu stdio üzerinden başlatır.
Elle test: uv run mcp dev ilanasist/mcp_server.py
"""
from mcp.server.fastmcp import FastMCP

from ilanasist import tools

mcp = FastMCP("ilanasist")


@mcp.tool()
def search_listings(category: str, city: str, district: str | None = None, listing_type: str | None = None,
                    rooms: str | None = None, max_price: int | None = None, limit: int = 5) -> dict:
    """Sentetik ilan veritabanında arama yapar. category: emlak | vasita; listing_type: satılık | kiralık."""
    args = {k: v for k, v in locals().items() if v is not None}
    return tools.search_listings.invoke(args)


@mcp.tool()
def get_price_stats(category: str, city: str, district: str | None = None, listing_type: str | None = None,
                    rooms: str | None = None) -> dict:
    """Eşleşen ilanların medyan, p25, p75 fiyat istatistiklerini döndürür."""
    args = {k: v for k, v in locals().items() if v is not None}
    return tools.get_price_stats.invoke(args)


@mcp.tool()
def check_fraud_signals(listing_id: str) -> dict:
    """Bir ilandaki kural tabanlı dolandırıcılık sinyallerini döndürür."""
    return tools.fraud_signals(listing_id)


if __name__ == "__main__":
    mcp.run()  # varsayılan taşıma: stdio
